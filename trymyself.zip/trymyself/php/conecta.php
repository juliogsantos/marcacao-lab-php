<?php

$host     = "localhost";
$username = "root";
$password = "";
$database = "7x";


$conexao = mysqli_connect($host, $username, $password, $database);
