<?php
include("../php/conecta.php");
include("../php/inserir.php");

$nome = $_POST["nome"];

if(insere($conexao, $nome)){

header("Location: ../index.php?adicionado=1");
    }else{
    header("Location: ../index.php?adicionado=0");
}
?>